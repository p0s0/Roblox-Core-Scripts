settings().FastLogSettings.ViewRbxBase = true
settings().FastLogSettings.DeviceLost = true
settings().FastLogSettings.Network = true
settings().FastLogSettings.RenderBreakdown = true
