local testModuleTable = {}

testModuleTable.Test = function()
	print("hello world this is a module")
end

return testModuleTable